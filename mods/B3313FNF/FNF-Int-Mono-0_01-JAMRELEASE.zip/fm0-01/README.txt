HELLO AND WELCOME TO FNF INTERNAL MONOLOGUE
THIS IS VERSION 0.01!

THIS VERSION IS ONLY INTENDED TO BE UPLOADED TO THE FRIDAY NIGHT MODDIN' HALLOWEEN CONTEST

NOT FOR PUBLIC UPLOAD PLEASE, IF REUPLOADED, IT WILL BE TAKEN DOWN

THIS IS VERY UNFINISHED AND HAS ONE SONG

Installation:
    Requires: Psych Engine 1.0
    - Install Psych 1.0
    - Place contents into mod folder.

"CUTSCENE":
https://files.catbox.moe/8a76h9.mp4 (explains most of it, has beeie spoilers)


Notes:

The Faceless Marios were done in two days, so sorry if they look a bit rushed.
Also the animations aren't meant to loop other than two idles however due to hold poses existing, it kinda screws it up.

Updates will come out!

Based off of B3313/Super Mario 64: Internal Plexus.* I know there's another B3313 mod, purely coincidental. No comparisons nor rivalry please!
*Note: this is based more around 0.7, or any version below 1.0. For those who aren't B3313 knowledgable, the area this is based upon had its (red) fog removed in 1.0 for an unknown reason.



Also there's some unused stuff in the files. Mostly stuff that didn't get to make the cut and the credits script from Funkin Galaxy. Ignore those.

One used and charted song, Facade.
Note: charting took like two days and the Psych Engine chart editor was bugging me that I had to use two different versions of Psych, one for charting and one for playing (the other one crashed in any song.) So if the chart kinda sucks, sorry.


Credits (for 0.01)
(Note, other users did work on this, but their content will be used in a later point in time.)
- Refer to credits_2024-11-01_23-59.png


Special Thanks:
- ChrisRLillo (making B3313)
- coldjam (BF facing back sprites used as placeholder.)

OST Upload: https://youtu.be/F5YzfqAo-uY?si=2kOE5bxaUkkXE7xG
